//ESSE CODIGO RODA NO NAVEGADOR (FRONT-END)
//Clouser - função javascript autoexecutavel
(function(){
    $('#clientes').on('click','.js-delete', function(){
        //CALLBACK
        let botaoclicado = $(this)
        $('#btnsim').attr('data-id',
            botaoclicado.attr('data-id'))
        $('#meumodal').modal('show')
    })
    $('#btnsim').on('click', function(){
        let botaoclicado = $(this)
        let codcliente = botaoclicado.attr('data-id')
        //chamar o backend
        $.ajax({
            url: '/clientes/delete/' + codcliente,
            method: 'GET',
            success: function(){
                window.location.href='/clientes'
            }
        })
    })
})()